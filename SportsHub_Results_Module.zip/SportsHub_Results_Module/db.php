<?php
$host = "localhost";
$dbname = "sportshub";
$username = "root";
$password = ""; // Change this if your MySQL setup has a password.

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit("Database connection failed. Check db.php settings and import database.sql.");
}
?>
